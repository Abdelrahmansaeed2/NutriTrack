
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:nutri_track/core/routing/routes.dart';
// import 'package:nutri_track/features/on_boarding/ui/screens/on_boarding_screen.dart';
// class AppRouter {
//   Route? generateRoute(RouteSettings settings) {
//     switch (settings.name) {
//       case Routes.onBoardingScreen:
//         return MaterialPageRoute(builder: (_) => const OnBoardingScreen());
//       //////////////////////
//      case Routes.homeScreen:
//        return MaterialPageRoute(
//           builder:
//               (_) => BlocProvider(
//                 create: (context) => getIt<Login>()..emitHomeStates(),
//                 child: HomeScreen(),
//               ),
//         );
//         case Routes.loginScreen:
//         return MaterialPageRoute(
//           builder:
//               (_) => BlocProvider(
//                 create: (context) => getIt<LoginCubit>(),
//                 child: LoginScreen(),
//               ),
//         );
//         case Routes.signUpScreen:
//         return MaterialPageRoute(
//           builder:
//               (_) => BlocProvider(
//                 create: (context) => getIt<SignupCubit>(),
//                 child: SignUpScreen(),
//               ),
//         );

//       ////////
//       default:
//         return null;
//     }
//   }
// }
