import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nutri_track/core/networking/api_service.dart';

import '../models/user_model.dart';

class AuthRepository {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final ApiClient _apiClient = ApiClient();

  Future<UserModel> loginWithEmailAndPassword(String email, String password) async {
    UserCredential credential = await _firebaseAuth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );

    User? user = credential.user;
    if (user == null) {
      throw Exception('Firebase authentication failed');
    }

    String? token = await user.getIdToken();
    if (token == null) {
      throw Exception('Failed to obtain authentication token');
    }

    final response = await _apiClient.get('/api/users/profile', token);

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      return UserModel.fromJson(data);
    } else if (response.statusCode == 401) {
      throw Exception('Unauthorized backend request');
    } else {
      throw Exception('Failed to sync profile data with backend');
    }
  }
}